public class Main {
    public static void main(String[] args) {
        MoleculaDeAgua agua = new MoleculaDeAgua();
        System.out.println("Molecula de agua creada con 2H y 1O");
    }
}