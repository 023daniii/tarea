public class Main {
    public static void main(String[] args) {
        Arana arana = new Arana();
        
        System.out.println("Arana creada con 8 patas y 2 colmillos");
        
        arana.mover();
        arana.tejer();
        arana.morder();
    }
}